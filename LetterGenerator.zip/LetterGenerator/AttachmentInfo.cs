﻿namespace LetterGenerator
{
    // Простой класс для хранения информации об одном приложении
    public class AttachmentInfo
    {
        public string Title { get; set; } = "";   // Название приложения 
        public string Content { get; set; } = ""; // Текст/содержимое приложения
        public int Pages { get; set; }            // Количество страниц, которое занимает приложение
    }
}