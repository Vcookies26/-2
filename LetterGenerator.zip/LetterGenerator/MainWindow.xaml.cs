﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;

namespace LetterGenerator
{
    public partial class MainWindow : Window
    {
        private List<AttachmentInfo> attachments = new List<AttachmentInfo>();
        private const int CHARS_PER_PAGE = 2500;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAddAttachment_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAttachmentTitle.Text))
            {
                MessageBox.Show("Введите название приложения.");
                return;
            }

            int pages = 1;
            int.TryParse(txtAttachmentPages.Text, out pages);

            if (pages <= 0)
                pages = 1;

            AttachmentInfo attachment = new AttachmentInfo
            {
                Title = txtAttachmentTitle.Text,
                Content = txtAttachmentContent.Text,
                Pages = pages
            };

            attachments.Add(attachment);

            lstAttachments.Items.Add($"{attachment.Title} ({attachment.Pages} л.)");

            txtAttachmentTitle.Clear();
            txtAttachmentContent.Clear();
            txtAttachmentPages.Text = "1";
        }

        private void BtnGenerate_Click(object sender, RoutedEventArgs e)
        {
            // ВАЛИДАЦИЯ
            if (string.IsNullOrWhiteSpace(txtLetterSubject.Text))
            {
                MessageBox.Show("Введите тему письма.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtRecipientOrg.Text))
            {
                MessageBox.Show("Введите организацию получателя.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Введите ФИО получателя.");
                return;
            }

            // ПРОВЕРКА ФОРМАТА ДАТ
            if (!IsValidDateFormat(txtEventDate.Text))
            {
                MessageBox.Show("Неверный формат даты события.\nИспользуйте формат: ДД.ММ.ГГГГ");
                return;
            }

            if (!IsValidDateFormat(txtContractDate.Text))
            {
                MessageBox.Show("Неверный формат даты договора.\nИспользуйте формат: ДД.ММ.ГГГГ");
                return;
            }

            if (!IsValidDateFormat(txtDeadlineDate.Text))
            {
                MessageBox.Show("Неверный формат срока погашения.\nИспользуйте формат: ДД.ММ.ГГГГ");
                return;
            }

            string templatePath = Path.Combine(Directory.GetCurrentDirectory(), "Templates", "Template.docx");

            if (!File.Exists(templatePath))
            {
                MessageBox.Show("Шаблон не найден:\n" + templatePath);
                return;
            }

            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Word Document|*.docx",
                FileName = $"Письмо_{DateTime.Now:yyyyMMdd_HHmmss}.docx"
            };

            if (saveDialog.ShowDialog() == true)
            {
                string outputPath = saveDialog.FileName;
                File.Copy(templatePath, outputPath, true);

                string attachmentsText = "";

                if (attachments.Count == 0)
                {
                    attachmentsText = "Отсутствуют";
                }
                else
                {
                    for (int i = 0; i < attachments.Count; i++)
                    {
                        attachmentsText += $"{i + 1}. {attachments[i].Title} на {attachments[i].Pages} л.";
                        if (i < attachments.Count - 1)
                        {
                            attachmentsText += "\n";
                        }
                    }
                }

                var replacements = new Dictionary<string, string>
                {
                    ["{LETTER_SUBJECT}"] = txtLetterSubject.Text,
                    ["{RECIPIENT_ORGANIZATION}"] = txtRecipientOrg.Text,
                    ["{POST}"] = txtPost.Text,
                    ["{FULL_NAME}"] = txtFullName.Text,
                    ["{RESPECT_NAME}"] = txtRespectName.Text,
                    ["{FAX}"] = txtFax.Text,
                    ["{EVENT_DATE}"] = txtEventDate.Text,
                    ["{BANK_NAME}"] = txtBankName.Text,
                    ["{DEBT_AMOUNT}"] = txtDebtAmount.Text,
                    ["{CONTRACT_DATE}"] = txtContractDate.Text,
                    ["{CONTRACT_NUMBER}"] = txtContractNumber.Text,
                    ["{DEADLINE_DATE}"] = txtDeadlineDate.Text,
                    ["{SIGNER_NAME}"] = txtSignerName.Text,
                    ["{CONTACT_PERSON}"] = txtContactPerson.Text,
                    ["{CONTACT_PHONE}"] = txtContactPhone.Text,
                    ["{ATTACHMENTS_LIST}"] = attachmentsText
                };

                ReplacePlaceholdersInDocument(outputPath, replacements);
                InsertAttachments(outputPath);

                MessageBox.Show("Письмо успешно создано:\n" + outputPath);
            }
        }

        // ПРОСТАЯ ПРОВЕРКА ФОРМАТА ДАТЫ (ДД.ММ.ГГГГ)
        private bool IsValidDateFormat(string date)
        {
            if (string.IsNullOrWhiteSpace(date))
                return false;

            DateTime result;
            return DateTime.TryParseExact(date.Trim(), "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
        }

        private void ReplacePlaceholdersInDocument(string docPath, Dictionary<string, string> replacements)
        {
            using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(docPath, true))
            {
                var mainPart = wordDoc.MainDocumentPart;
                if (mainPart == null) return;

                var body = mainPart.Document.Body;
                if (body == null) return;

                ReplaceInContainer(body, replacements);

                foreach (var headerPart in mainPart.HeaderParts)
                {
                    ReplaceInContainer(headerPart.Header, replacements);
                }

                foreach (var footerPart in mainPart.FooterParts)
                {
                    ReplaceInContainer(footerPart.Footer, replacements);
                }

                mainPart.Document.Save();
            }
        }

        private void ReplaceInContainer(OpenXmlElement? element, Dictionary<string, string> replacements)
        {
            if (element == null) return;

            var texts = element.Descendants<Text>().ToList();

            foreach (var text in texts)
            {
                foreach (var replacement in replacements)
                {
                    if (text.Text.Contains(replacement.Key))
                    {
                        text.Text = text.Text.Replace(replacement.Key, replacement.Value);
                    }
                }
            }
        }

        private void InsertAttachments(string docPath)
        {
            if (attachments.Count == 0) return;

            using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(docPath, true))
            {
                var mainPart = wordDoc.MainDocumentPart;
                if (mainPart == null) return;

                Body? body = mainPart.Document.Body;
                if (body == null) return;

                for (int i = 0; i < attachments.Count; i++)
                {
                    var attachment = attachments[i];

                    body.Append(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));

                    string appName = attachments.Count == 1 ? "Приложение" : $"Приложение {i + 1}";

                    Paragraph rightParagraph = new Paragraph(
                        new ParagraphProperties(new Justification() { Val = JustificationValues.Right }),
                        new Run(new Text(appName)));
                    body.Append(rightParagraph);

                    Paragraph centerParagraph = new Paragraph(
                        new ParagraphProperties(new Justification() { Val = JustificationValues.Center }),
                        new Run(new Text(attachment.Title)));
                    body.Append(centerParagraph);

                    int maxChars = attachment.Pages * CHARS_PER_PAGE;
                    string content = attachment.Content;

                    if (content.Length > maxChars)
                    {
                        content = content.Substring(0, maxChars);
                    }

                    body.Append(new Paragraph(new Run(new Text(content))));

                    for (int p = 1; p < attachment.Pages; p++)
                    {
                        body.Append(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));
                    }
                }

                mainPart.Document.Save();
            }
        }
    }
}